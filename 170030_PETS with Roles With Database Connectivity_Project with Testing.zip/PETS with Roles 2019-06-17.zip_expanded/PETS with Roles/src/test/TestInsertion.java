package test;

/**
 * 
 * Test the insertion of data in database
 * 
 * @author Shivam Singhal
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.junit.Test;
import static org.junit.Assert.assertFalse;


public class TestInsertion {
	@Test
	public void insertion() throws SQLException {
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3308/pets_database?user=root&password=root");
		String query = "insert into defects(defects_id,defects_name,defects_description) values(?,?,?)";
		PreparedStatement stmt = conn.prepareStatement(query);
		stmt.setInt(1, 4);
		stmt.setString(2, "Null Pointer");
		stmt.setString(3, "Urgent Recovery Needed");
		stmt.execute();
		Statement retrieveStatement = conn.createStatement();
		String rq = "select * from defects where defects_id=4";
		ResultSet rs = retrieveStatement.executeQuery(rq);
		assertFalse(rs==null);
	}
}
