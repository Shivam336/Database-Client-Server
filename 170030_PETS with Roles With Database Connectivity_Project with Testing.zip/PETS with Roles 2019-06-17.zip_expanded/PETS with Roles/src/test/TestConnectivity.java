package test;

/**
 * 
 * Test the Connectivity of database
 * 
 * @author Shivam Singhal
 */

import java.sql.DriverManager;
import java.sql.SQLException;
import org.junit.Test;
import static org.junit.Assert.assertTrue;

public class TestConnectivity {
	@Test
	public void connectivity(){
		try {
			DriverManager.getConnection("jdbc:mysql://localhost:3308/pets_database?user=root&password=root");
		} catch (SQLException e) {
			assertTrue(false);
			return;
		}
		assertTrue(true);
	}
}
