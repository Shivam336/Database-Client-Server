/**
 * 
 * Database & Client Server
 * 170030 | Shivam Singhal
 * 
 * Week 12 Sh 2
 * 3.  Write a program for retrieving records from table.         
 * 
 * @author Shivam Sighal
 * 
 */

import java.sql.*;
public class Q3Retrieve{
	public static void main (String ar[]){	
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/w12shdb?user=root&password=");
			PreparedStatement ps = con.prepareStatement("select * from employees");
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				int empid = rs.getInt(1);
				String firstName = rs.getString(2);
				String lastName = rs.getString(3);
				int salary = rs.getInt(4);
				int deptid = rs.getInt(5);
				String email=rs.getString(6);
				String city=rs.getString(7);
				System.out.println("Employee id\t"+empid);
				System.out.println("First Name\t"+firstName);
				System.out.println("Last Name\t"+lastName);
				System.out.println("Salary\t"+salary);
				System.out.println("Department id\t"+deptid);
				System.out.println("Email id\t"+email);
				System.out.println("City\t"+city);
				System.out.println("\n==============================\n");	
			}

		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}