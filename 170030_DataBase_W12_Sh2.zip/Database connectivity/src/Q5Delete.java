/**
 * 
 * Database & Client Server
 * 170030 | Shivam Singhal
 * 
 * Week 12 Sh 2
 * 5.  Write a program for deleting records from table.         
 * 
 * @author Shivam Sighal
 * 
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
class Q5Delete{
	public static void main (String ar[]){
		int eno = 1;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/w12shdb?user=root&password=");
			PreparedStatement ps = con.prepareStatement("delete from employees where empid=?");
			ps.setInt(1,eno);
			int a =ps.executeUpdate();
			if (a==1)
				System.out.println("Record Deleted");
			else
				System.out.println("Record not found");
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}