
/**
 * 
 * Database & Client Server
 * 170030 | Shivam Singhal
 * 
 * Week 12 Sh 2
 * 2. Write a program for inserting records into table.
 * 
 * @author Shivam Sighal
 * 
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
public class Q2Insert{
	public static void main (String ar[]){	
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/w12shdb?user=root&password=");
			String query = "INSERT INTO employees values(2,'Manik','Sangal',4000,1,'manik.sangal@','Pune'),"
					+ "(3,'Shiv','Singh',3000,1,'shiv.sing@','Delhi')"; 
			Statement st = con.createStatement();
			st.execute(query);
			System.out.println("Data Inserted Successfully");
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}