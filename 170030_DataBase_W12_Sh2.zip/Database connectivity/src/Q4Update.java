
/**
 * 
 * Database & Client Server
 * 170030 | Shivam Singhal
 * 
 * Week 12 Sh 2
 * 4. Write a program for updating records into table.     
 * 
 * @author Shivam Sighal
 * 
 */

import java.sql.*;
public class Q4Update{
	public static void main (String ar[]){
		int eno = 1;
		int dn = 2;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/w12shdb?user=root&password=");
			PreparedStatement ps = con.prepareStatement("update employees set deptid = ? where empid=?");
			ps.setInt(1,dn);
			ps.setInt(2,eno);
			int a =ps.executeUpdate();
			if (a==1)
				System.out.println("Record updated");
			else
				System.out.println("Record not found");
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}