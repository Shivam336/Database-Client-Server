
/**
 * 
 * Database & Client Server
 * 170030 | Shivam Singhal
 * 
 * Week 12 Sh 2
 * 7.  Write a program to display the department number and average salary for each department.   
 * 
 * @author Shivam Sighal
 * 
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
public class Q7RetrieveDepNoAverageSalary{
	public static void main (String ar[]){	
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/w12shdb?user=root&password=");
			PreparedStatement ps = con.prepareStatement("SELECT deptid,avg(salary)" + 
					"FROM employees group by deptid");
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				int salary = rs.getInt(2);
				int deptid = rs.getInt(1);

				System.out.println("Department id\t"+deptid);
				System.out.println("Average salary\t"+salary);

				System.out.println("\n==============================\n");	
			}
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}