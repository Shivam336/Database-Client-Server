
/**
 * 
 * Database & Client Server
 * 170030 | Shivam Singhal
 * 
 * Week 12 Sh 2
 * 7.  Write a program to display the department number and average salary for each department.   
 * 
 * @author Shivam Sighal
 * 
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
public class Q7RetrieveDepNoAverageSalary{
	public static void main (String ar[]){	
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/w12shdb?user=root&password=");
			PreparedStatement ps = con.prepareStatement("SELECT deptid, AVG(salary)" + 
					"FROM employees GROUP BY deptid HAVING COUNT(*) > 0");
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				int empid = rs.getInt(1);
				String firstName = rs.getString(2);
				String lastName = rs.getString(3);
				int salary = rs.getInt(4);
				int deptid = rs.getInt(5);
				String email=rs.getString(6);
				String city=rs.getString(7);
				System.out.println("Salary\t"+salary);
				System.out.println("Department id\t"+deptid);
				System.out.println("\n==============================\n");	
			}
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}