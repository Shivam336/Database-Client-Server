/**
 * 
 * Database & Client Server
 * 170030 | Shivam Singhal
 * 
 * Week 12 Sh 2
 * 1. Write a program for creating a table.       
 * 
 * @author Shivam Sighal
 * 
 */

import java.sql.*;
public class Q1Create{
	public static void main (String ar[]){	
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/w12shdb?user=root&password=");
			String query = "CREATE TABLE employees " +
					"(empid INTEGER not NULL, " +
					" firstname VARCHAR(25), " + 
					" lastname VARCHAR(25), " + 
					" salary INTEGER, " + "deptid INTEGER, "+"email VARCHAR(25), "+"city VARCHAR(25), "+
					" PRIMARY KEY ( empid ))"; 
			Statement st = con.createStatement();
			st.executeUpdate(query);
			System.out.println("Table Created Successfully");
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}